package com.example.schedule

import android.content.Context

data class Lesson(val day: Int, val start: Int, val end: Int, val room: String, val name: String) {
    fun time() = "%02d:%02d–%02d:%02d".format(start / 60, start % 60, end / 60, end % 60)
    companion object {
        val DAYS = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
    }
}

object Store {
    private const val KEY = "lessons"
    fun load(c: Context): MutableList<Lesson> {
        val s = c.getSharedPreferences("s", 0).getString(KEY, "") ?: ""
        return s.lines().mapNotNull {
            val p = it.split("|")
            if (p.size != 5) null else Lesson(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3], p[4])
        }.toMutableList()
    }
    fun save(c: Context, l: List<Lesson>) {
        val s = l.joinToString("\n") { "${it.day}|${it.start}|${it.end}|${it.room}|${it.name}" }
        c.getSharedPreferences("s", 0).edit().putString(KEY, s).apply()
    }
}
