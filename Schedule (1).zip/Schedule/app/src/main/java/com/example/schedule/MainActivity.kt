package com.example.schedule

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var day = 1
    private lateinit var list: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Lesson.DAYS)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { day = pos + 1; refresh() }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        list = ListView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        list.setOnItemLongClickListener { _, _, pos, _ -> confirmDelete(pos); true }
        val add = Button(this).apply { text = "+ Добавить урок"; setOnClickListener { addDialog() } }
        val hint = TextView(this).apply { text = "Долгое нажатие на урок — удалить" }
        listOf(spin, list, hint, add).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun today() = Store.load(this).filter { it.day == day }.sortedBy { it.start }

    private fun refresh() {
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            today().map { "${it.time()}  ${it.name}  (каб. ${it.room})" })
    }

    private fun confirmDelete(pos: Int) {
        val l = today()[pos]
        AlertDialog.Builder(this).setTitle("Удалить «${l.name}»?")
            .setPositiveButton("Удалить") { _, _ ->
                val all = Store.load(this); all.remove(l); save(all)
            }.setNegativeButton("Отмена", null).show()
    }

    private fun save(all: List<Lesson>) { Store.save(this, all); ScheduleWidget.refresh(this); refresh() }

    private fun time(s: String): Int? {
        val p = s.trim().split(":", ".")
        val h = p.getOrNull(0)?.toIntOrNull() ?: return null
        val m = p.getOrNull(1)?.toIntOrNull() ?: return null
        return if (p.size == 2 && h in 0..23 && m in 0..59) h * 60 + m else null
    }

    private fun field(h: String, t: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply { hint = h; inputType = t }

    private fun addDialog() {
        val name = field("Предмет"); val s = field("Начало (08:30)"); val e = field("Конец (09:15)"); val r = field("Кабинет")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }
        listOf(name, s, e, r).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle(Lesson.DAYS[day - 1]).setView(box)
            .setPositiveButton("Добавить") { _, _ ->
                val a = time(s.text.toString()); val z = time(e.text.toString())
                val n = name.text.toString().replace("|", " ").trim()
                if (a == null || z == null || z <= a || n.isEmpty())
                    Toast.makeText(this, "Проверьте название и время", Toast.LENGTH_LONG).show()
                else save(Store.load(this).apply { add(Lesson(day, a, z, r.text.toString().replace("|", " ").trim(), n)) })
            }.setNegativeButton("Отмена", null).show()
    }
}
