package com.example.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId

class ScheduleWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val now = LocalDateTime.now()
        val dow = now.dayOfWeek.value
        val min = now.hour * 60 + now.minute
        val day0 = now.toLocalDate().atStartOfDay()
        val all = Store.load(ctx)

        var head = ""; var name = "Уроков нет"; var info = "Добавьте расписание в приложении"
        var label = ""; var target: LocalDateTime? = null

        val cur = all.firstOrNull { it.day == dow && min >= it.start && min < it.end }
        if (cur != null) {
            head = "Сейчас идёт"; name = cur.name; info = "${cur.time()} · каб. ${cur.room}"
            label = "Закончится через "; target = day0.plusMinutes(cur.end.toLong())
        } else {
            for (off in 0..7) {
                val d = (dow - 1 + off) % 7 + 1
                val n = all.filter { it.day == d && (off > 0 || it.start > min) }.minByOrNull { it.start } ?: continue
                head = when (off) { 0 -> "Следующий урок"; 1 -> "Следующий урок · завтра"
                    else -> "Следующий урок · ${Lesson.DAYS[d - 1].lowercase()}" }
                name = n.name; info = "${n.time()} · каб. ${n.room}"
                if (off == 0) { label = "Начнётся через "; target = day0.plusMinutes(n.start.toLong()) }
                break
            }
        }

        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val v = RemoteViews(ctx.packageName, R.layout.widget).apply {
            setTextViewText(R.id.head, head); setTextViewText(R.id.name, name); setTextViewText(R.id.info, info)
            setOnClickPendingIntent(R.id.root, open)
            if (target != null) {
                val secs = Duration.between(now, target).seconds.coerceAtLeast(0)
                setViewVisibility(R.id.timer, View.VISIBLE)
                setChronometerCountDown(R.id.timer, true)
                setChronometer(R.id.timer, SystemClock.elapsedRealtime() + secs * 1000, "$label%s", true)
            } else setViewVisibility(R.id.timer, View.GONE)
        }
        ids.forEach { mgr.updateAppWidget(it, v) }

        // перерисовать виджет ровно в момент начала/конца урока
        val next = (target?.plusSeconds(2)) ?: day0.plusDays(1).plusMinutes(5)
        val at = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val i = Intent(ctx, ScheduleWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        val pi = PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    companion object {
        fun refresh(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, ScheduleWidget::class.java))
            if (ids.isNotEmpty()) ScheduleWidget().onUpdate(ctx, m, ids)
        }
    }
}
