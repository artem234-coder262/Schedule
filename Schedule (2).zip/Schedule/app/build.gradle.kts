plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.schedule"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.schedule"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("release.jks"); storePassword = "schedule123"
            keyAlias = "key"; keyPassword = "schedule123"
        }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("fixed") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
