package com.example.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.time.ZoneId

class ScheduleWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val now = LocalDateTime.now()
        val dow = now.dayOfWeek.value
        val min = now.hour * 60 + now.minute
        val all = Store.load(ctx)

        var head = ""; var name = "Уроков нет"; var info = "Добавьте расписание в приложении"
        var nextCheck = now.plusDays(1).toLocalDate().atStartOfDay().plusMinutes(5)

        val cur = all.firstOrNull { it.day == dow && min >= it.start && min < it.end }
        if (cur != null) {
            head = "Сейчас идёт"; name = cur.name; info = "${cur.time()} · каб. ${cur.room}"
            nextCheck = now.toLocalDate().atStartOfDay().plusMinutes(cur.end.toLong())
        } else {
            for (off in 0..7) {
                val d = (dow - 1 + off) % 7 + 1
                val n = all.filter { it.day == d && (off > 0 || it.start > min) }.minByOrNull { it.start } ?: continue
                head = when (off) { 0 -> "Следующий урок"; 1 -> "Следующий урок · завтра"
                    else -> "Следующий урок · ${Lesson.DAYS[d - 1].lowercase()}" }
                name = n.name; info = "${n.time()} · каб. ${n.room}"
                if (off == 0) nextCheck = now.toLocalDate().atStartOfDay().plusMinutes(n.start.toLong())
                break
            }
        }

        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val v = RemoteViews(ctx.packageName, R.layout.widget).apply {
            setTextViewText(R.id.head, head); setTextViewText(R.id.name, name); setTextViewText(R.id.info, info)
            setOnClickPendingIntent(R.id.root, open)
        }
        ids.forEach { mgr.updateAppWidget(it, v) }

        // обновиться ровно в момент начала/конца урока
        val i = Intent(ctx, ScheduleWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        val pi = PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val at = nextCheck.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
            .setAndAllowWhileIdle(AlarmManager.RTC, at, pi)
    }

    companion object {
        fun refresh(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, ScheduleWidget::class.java))
            if (ids.isNotEmpty()) ScheduleWidget().onUpdate(ctx, m, ids)
        }
    }
}
